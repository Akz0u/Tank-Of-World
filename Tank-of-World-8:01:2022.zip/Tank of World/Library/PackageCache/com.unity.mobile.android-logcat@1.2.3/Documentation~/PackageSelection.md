### Package Selection
The package selection list contains:
- Package of the top activity which is currently running on the selected device.
- Package from the player settings if it's running on the selected device (Doesn't have to be the the top running activity).

You can only select one package at a time, only the log messages coming from the selected package will be shown in the logcat console window. 

Alternatively you can select **No Filter** - messages coming from all package will be shown.
