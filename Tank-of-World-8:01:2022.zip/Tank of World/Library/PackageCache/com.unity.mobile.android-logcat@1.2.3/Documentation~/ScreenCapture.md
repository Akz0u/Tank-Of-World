### Screen Capture

**Screen Capture** is available from Tools menu.

<br>

![Tools Menu](images/toolsmenu.png)

<br>

You can use the **Screen Capture** button on the toolbar to capture a screenshot of the selected device. You can also **Save** the screenshot as a file.  
![Device Screen Capture](images/device_screen_capture.png)