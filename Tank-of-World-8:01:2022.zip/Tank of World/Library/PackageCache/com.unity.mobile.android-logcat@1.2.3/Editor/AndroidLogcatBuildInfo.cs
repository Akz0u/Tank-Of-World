namespace Unity.Android.Logcat
{
    internal struct BuildInfo
    {
        public string buildType;
        public string scriptingImplementation;
        public string cpu;
    }
}
