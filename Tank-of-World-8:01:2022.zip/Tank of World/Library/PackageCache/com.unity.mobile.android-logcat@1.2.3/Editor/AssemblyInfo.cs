using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Mobile.AndroidLogcat.EditorTests")]
[assembly: InternalsVisibleTo("Unity.Mobile.AndroidLogcat.EditorPerformanceTests")]
